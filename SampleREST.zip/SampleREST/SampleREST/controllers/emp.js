﻿//Main File who deal with DB and communicate with server

var db = require("../core/db");
var httpMsg = require("../core/httpMsgs");
var util = require("util");

exports.getList = function (req, resp) {

    db.executeSql("SELECT * From emp", function (data, err) {

        if (err) {
           // console.log(err);
            //resp.writeHeader(500, "Internal error occured", { "Content-Type": "text/html" });
            //resp.write("<html><head><title>500</title></head><body>500 Internal Err Detail :" + err + "</body></html>");


            //resp.writeHeader(500, { "Content-Type": "application/json" });
            //resp.write(JSON.stringify({ data: "Error Occured :" + err }));

            httpMsg.httpMsg500(req, resp, err);

        }
        else {
            //resp.writeHeader(200, { "Content-Type": "application/json" });
            //resp.write(JSON.stringify(data));

            httpMsg.sendJSON(req, resp, data);
        }
        // resp.end();

    });
};

exports.get = function (req, res, empNo) {

    db.executeSql("SELECT * From emp where empId=" + empNo, function (data, err) {

        if (err) {
            httpMsg.httpMsg500(req, resp, err);
        }
        else {
            httpMsg.sendJSON(req, resp, data);
        }
    });
}

exports.add = function (req, resp, reqBody) {

    try {
        if (!reqBody) throw new Error("Input Not Valid");
        var data = JSON.parse(reqBody);
        if (data) {
            var sql = "Insert into emp (empId,EmpName,sal,isActive) values ";
            sql += util.format("(%d,'%s',%d,%d)", data.empId, data.EmpName, data.sal, data.isActive);
            db.executeSql(sql, function (data, err) {

                if (err) {
                    httpMsg.httpMsg500(req, resp, err);
                }
                else {
                    httpMsg.send200(req, resp);
                }
            });

           
        }
        else {
            throw new Error("Input Not Valid");
        }

    }
    catch (ex) {

        httpMsg.httpMsg500(req, resp, ex);
    }
   
};

exports.update = function (req, res, reqBody) {
};

exports.delete = function (req, res, empNo) {
}; 