﻿var setting = require("../settings");


exports.httpMsg500 = function (req, resp, err) {

    if (setting.httpMassageFormat === "HTML") {

        resp.writeHead(500, "Internal error occured", { "Content-Type": "text/html" });
        resp.write("<html><head><title>500</title></head><body>500 Internal Err. Details :" + err + "</body></html>");
    }
    else {

        resp.writeHeader(500, { "Content-Type": "application/json" });
        resp.write(JSON.stringify({ data: "Error Occured :" + err }));
    }
    resp.end();

}

exports.httpMsg404 = function (req, resp, err) {

    if (setting.httpMassageFormat === "HTML") {

        resp.writeHead(404, "Internal error occured", { "Content-Type": "text/html" });
        resp.write("<html><head><title>404</title></head><body>404 Internal Err. Details :" + err + "</body></html>");
    }
    else {

        resp.writeHead(404, { "Content-Type": "application/json" });
        resp.write(JSON.stringify({ data: "Error Occured :" + err }));
    }

    resp.end();

}

exports.sendJSON = function (req, resp, data) {

    resp.writeHead(200, { "Content-Type": "application/json" });
    if (data) {
        resp.write(JSON.stringify(data));
    }
    resp.end();
}

exports.send200 = function (req, resp) {

    resp.writeHead(200, { "Content-Type": "application/json" });
    resp.end();
}

exports.showHome = function (req, resp) {

    if (setting.httpMassageFormat === "HTML") {

        resp.writeHead(200, { "Content-Type": "text/html" });
        resp.write("<html><head><title></title></head><body>Valid Endpoints : <br> /employees - GET -  To List Of All Employee <br> /employees/empno - GET- Search a employee</body></html>");

    }
    else {

        resp.writeHead(200, { "Content-Type": "application/json" });
        resp.write(JSON.stringify([
            { url: "/employees", operation: "GET", description: "To List of all Employees" },
            { url: "/employees/empno", operation: "GET", description: "To search a employee" }
        ]));
    }
    resp.end();

}