﻿var http = require("http");
console.log('Node version: ' + process.version);
var emp = require("../controllers/emp");
var setting = require("../settings");
var httpMsg = require("../core/httpMsgs");

var server = http.createServer(function (req, resp) {

    switch (req.method) {

        case "GET":
            if (req.url === "/") {
                httpMsg.showHome(req, resp);
            }
            else if (req.url === "/employees") {
                emp.getList(req, resp);
            }
            else if (req.url === "/employees/empno") {
                //emp.get(req, resp);
            }
            break;
        case "POST":
            if (req.url === "/employees") {
                var reqBody = '';
                req.on("data", function (data) {

                    reqBody += data;
                });

                req.on("end", function () {

                    emp.add(req, resp, reqBody);
                });
            }
            else {
                httpMsg.httpMsg500(req, resp,null);
            }
            break;
        case "PUT":
            break;
        case "DELETE":
            break;

        default:
            break;
    }


}).listen(setting.webPort, function () {
    console.log("Server is running @ :" + setting.webPort)
});

