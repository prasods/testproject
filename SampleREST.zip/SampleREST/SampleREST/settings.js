﻿//All Configurable setting will be in a single place
///Created By Ashish Shukla

exports.dbConfig =
    {
        user: "root",
        password: "root",
        server: "127.0.0.1",//"azfbisdd01 10.159.80.39",
        database: "test",
        port: 3306
        //options: {
        //    trustedConnection: true
        //}
        //user: "svcfbio@microsoft.com@fbis",
        //password: "$vcFbis81o@2015",
        //server: "tcp:fbis.database.windows.net",//"azfbisdd01",
        //options: {
        //    database: 'reportperformance' //update me
        //},
        //port: 1433


    }

exports.webPort = 9000;
exports.httpMassageFormat = "JSON";